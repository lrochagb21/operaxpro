# OperaxPro 🚀
> Plataforma SaaS de gestão de equipes de campo

## Stack
- **Frontend**: Next.js 15 + Tailwind CSS
- **Banco**: Supabase (PostgreSQL)
- **Deploy**: Vercel
- **Auth**: Supabase Auth

## Setup local

1. Clone o repositório
2. Instale as dependências:
   ```bash
   npm install
   ```
3. Copie o arquivo de variáveis:
   ```bash
   cp .env.example .env.local
   ```
4. Preencha o `.env.local` com suas chaves do Supabase (Settings → API)

5. Rode o projeto:
   ```bash
   npm run dev
   ```

6. Acesse: http://localhost:3000

## Deploy na Vercel

1. Importe o repositório na Vercel
2. Configure as variáveis de ambiente no painel da Vercel
3. Deploy automático a cada `git push`

## Módulos
- ✅ Login com Supabase Auth
- ✅ Dashboard com KPIs
- ✅ Técnicos
- 🔄 Clientes
- 🔄 Ordens de Serviço
- 🔄 Estoque
- 🔄 Financeiro
- 🔄 Agenda
- 🔄 Relatórios
- 🔄 Painel Super Admin
