'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase'
import Sidebar from '@/components/layout/Sidebar'

export default function AppLayout({ children }) {
  const [user, setUser]       = useState(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    async function checkAuth() {
      const { data: { session } } = await supabase.auth.getSession()
      if (!session) { router.push('/login'); return }
      const { data: perfil } = await supabase
        .from('usuarios').select('nome,perfil,empresa_id')
        .eq('auth_id', session.user.id).single()
      setUser({ ...session.user, ...perfil })
      setLoading(false)
    }
    checkAuth()
  }, [router])

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center" style={{background:'#0B1120'}}>
      <div className="text-sm font-semibold animate-pulse" style={{color:'#3D5070'}}>Carregando...</div>
    </div>
  )

  return (
    <div className="flex h-screen overflow-hidden" style={{background:'#0B1120'}}>
      <Sidebar user={user}/>
      <main className="flex-1 overflow-y-auto">{children}</main>
    </div>
  )
}
