'use client'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase'

const nav = [
  { group: 'Principal', items: [
    { href: '/dashboard',   icon: '📊', label: 'Dashboard' },
    { href: '/agenda',      icon: '📅', label: 'Agenda' },
    { href: '/os',          icon: '📋', label: 'Ordens de Serviço' },
  ]},
  { group: 'Cadastros', items: [
    { href: '/tecnicos',    icon: '👷', label: 'Técnicos' },
    { href: '/clientes',    icon: '👥', label: 'Clientes' },
  ]},
  { group: 'Operacional', items: [
    { href: '/estoque',     icon: '📦', label: 'Estoque' },
    { href: '/financeiro',  icon: '💰', label: 'Financeiro' },
    { href: '/relatorios',  icon: '📈', label: 'Relatórios' },
  ]},
]

export default function Sidebar({ user }) {
  const path = usePathname()
  const router = useRouter()

  async function logout() {
    await supabase.auth.signOut()
    router.push('/login')
  }

  return (
    <aside className="flex flex-col h-screen" style={{width:230,minWidth:230,background:'#0F1729',borderRight:'1px solid rgba(96,165,250,0.07)'}}>
      {/* Logo */}
      <div className="px-4 py-5" style={{borderBottom:'1px solid rgba(96,165,250,0.07)'}}>
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{background:'#1A56DB',boxShadow:'0 0 14px rgba(26,86,219,.4)'}}>
            <svg width="18" height="18" viewBox="0 0 28 28" fill="none">
              <rect x="3" y="3" width="10" height="10" rx="2.5" fill="white"/>
              <rect x="15" y="3" width="10" height="10" rx="2.5" fill="white" opacity="0.5"/>
              <rect x="3" y="15" width="10" height="10" rx="2.5" fill="white" opacity="0.5"/>
              <path d="M15 20.5L18.5 24.5L25 16" stroke="white" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <span className="text-base font-black tracking-tight" style={{color:'#EEF2FF'}}>
            Operax<span style={{color:'#67E8F9',fontWeight:400}}>Pro</span>
          </span>
        </div>
      </div>

      {/* Nav */}
      <div className="flex-1 overflow-y-auto px-3 py-4 flex flex-col gap-5">
        {nav.map(group => (
          <div key={group.group}>
            <div className="text-xs font-bold mb-2 px-2 tracking-widest uppercase" style={{color:'#3D5070'}}>{group.group}</div>
            {group.items.map(item => {
              const active = path === item.href || path.startsWith(item.href + '/')
              return (
                <Link key={item.href} href={item.href}
                  className="flex items-center gap-2.5 px-3 py-2.5 rounded-xl mb-0.5 text-sm font-medium transition-all relative"
                  style={{
                    background: active ? 'rgba(26,86,219,0.18)' : 'transparent',
                    color: active ? '#60A5FA' : '#8899BB',
                    fontWeight: active ? 700 : 500,
                  }}>
                  {active && <span className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 rounded-r" style={{background:'#1A56DB'}}/>}
                  <span className="text-base w-5 text-center">{item.icon}</span>
                  {item.label}
                </Link>
              )
            })}
          </div>
        ))}
      </div>

      {/* User + Logout */}
      <div className="px-3 py-4" style={{borderTop:'1px solid rgba(96,165,250,0.07)'}}>
        <div className="flex items-center gap-3 px-3 py-2 rounded-xl mb-1">
          <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-black text-white flex-shrink-0" style={{background:'linear-gradient(135deg,#1A56DB,#06B6D4)'}}>
            {user?.email?.[0]?.toUpperCase() || 'U'}
          </div>
          <div className="overflow-hidden">
            <div className="text-sm font-bold truncate" style={{color:'#EEF2FF'}}>{user?.nome || 'Usuário'}</div>
            <div className="text-xs truncate" style={{color:'#3D5070'}}>{user?.perfil || 'admin'}</div>
          </div>
        </div>
        <button onClick={logout} className="flex items-center gap-2 w-full px-3 py-2 rounded-xl text-sm font-semibold transition-all" style={{color:'#3D5070'}}
          onMouseEnter={e=>{e.currentTarget.style.background='rgba(239,68,68,.1)';e.currentTarget.style.color='#FCA5A5'}}
          onMouseLeave={e=>{e.currentTarget.style.background='transparent';e.currentTarget.style.color='#3D5070'}}>
          🚪 Sair do sistema
        </button>
      </div>
    </aside>
  )
}
