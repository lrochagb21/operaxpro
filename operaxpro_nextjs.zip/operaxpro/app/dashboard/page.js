'use client'
import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

function StatCard({ icon, label, value, change, positive, color }) {
  const colors = { blue:'#1A56DB', cyan:'#06B6D4', success:'#10B981', warning:'#F59E0B', purple:'#8B5CF6', danger:'#EF4444' }
  return (
    <div className="rounded-2xl p-5 relative overflow-hidden transition-all hover:scale-[1.02]" style={{background:'#0F1729',border:'1px solid rgba(96,165,250,0.07)'}}>
      <div className="absolute top-0 left-0 right-0 h-0.5 rounded-t-2xl" style={{background:colors[color]}}/>
      <div className="text-xl mb-3">{icon}</div>
      <div className="text-xs font-bold mb-1.5 tracking-widest uppercase" style={{color:'#3D5070'}}>{label}</div>
      <div className="text-3xl font-black tracking-tight" style={{color:'#EEF2FF'}}>{value}</div>
      <div className="text-xs font-bold mt-2" style={{color: positive ? '#10B981' : '#EF4444'}}>{change}</div>
    </div>
  )
}

export default function Dashboard() {
  const [stats, setStats] = useState({ tecnicos:0, clientes:0, osAbertas:0, osConc:0, fatMes:'R$0', estBaixo:0 })
  const [recentOS, setRecentOS] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => { loadData() }, [])

  async function loadData() {
    try {
      const [tecs, clis, os, est, fin] = await Promise.all([
        supabase.from('usuarios').select('id', {count:'exact'}).eq('perfil','tecnico').eq('status','ativo'),
        supabase.from('clientes').select('id', {count:'exact'}),
        supabase.from('ordens_servico').select('*').order('criado_em', {ascending:false}).limit(6),
        supabase.from('estoque').select('quantidade,quantidade_minima'),
        supabase.from('financeiro').select('valor,tipo').eq('tipo','receita'),
      ])
      const osAbertas = os.data?.filter(o => o.status !== 'Concluída' && o.status !== 'Cancelada').length || 0
      const osConc    = os.data?.filter(o => o.status === 'Concluída').length || 0
      const estBaixo  = est.data?.filter(e => e.quantidade <= e.quantidade_minima).length || 0
      const fat       = fin.data?.reduce((a, f) => a + parseFloat(f.valor), 0) || 0
      setStats({ tecnicos: tecs.count||0, clientes: clis.count||0, osAbertas, osConc, fatMes: 'R$'+Math.round(fat/1000)+'k', estBaixo })
      setRecentOS(os.data || [])
    } catch(e) { console.error(e) }
    setLoading(false)
  }

  const statusBadge = s => ({
    'Concluída':      'rgba(16,185,129,.15)|#34D399',
    'Em Andamento':   'rgba(96,165,250,.15)|#93C5FD',
    'Aberta':         'rgba(245,158,11,.15)|#FCD34D',
    'Aguardando Peça':'rgba(139,92,246,.15)|#C4B5FD',
    'Cancelada':      'rgba(239,68,68,.15)|#FCA5A5',
  }[s] || 'rgba(96,165,250,.15)|#93C5FD').split('|')

  const fmtDate = d => d ? new Date(d).toLocaleDateString('pt-BR') : '—'

  return (
    <div className="p-6">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-black tracking-tight" style={{color:'#EEF2FF'}}>Dashboard</h1>
        <p className="text-sm mt-1" style={{color:'#3D5070'}}>Visão geral do sistema</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
        <StatCard icon="👷" label="Técnicos" value={stats.tecnicos} change="↑ ativos" positive color="blue"/>
        <StatCard icon="👥" label="Clientes" value={stats.clientes} change="↑ este mês" positive color="cyan"/>
        <StatCard icon="📋" label="OS Abertas" value={stats.osAbertas} change="em andamento" positive={false} color="warning"/>
        <StatCard icon="✅" label="Concluídas" value={stats.osConc} change="↑ este mês" positive color="success"/>
        <StatCard icon="💰" label="Faturamento" value={stats.fatMes} change="↑ 12%" positive color="purple"/>
        <StatCard icon="📦" label="Estoque Baixo" value={stats.estBaixo} change="verificar!" positive={false} color="danger"/>
      </div>

      {/* Tabela OS recentes */}
      <div className="rounded-2xl overflow-hidden" style={{background:'#0F1729',border:'1px solid rgba(96,165,250,0.07)'}}>
        <div className="px-5 py-4 flex items-center justify-between" style={{borderBottom:'1px solid rgba(96,165,250,0.07)'}}>
          <span className="font-black" style={{color:'#EEF2FF'}}>Últimas Ordens de Serviço</span>
        </div>
        {loading ? (
          <div className="p-8 text-center text-sm" style={{color:'#3D5070'}}>Carregando...</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr style={{background:'rgba(15,23,41,0.6)'}}>
                  {['#','Cliente','Técnico','Serviço','Status','Data'].map(h => (
                    <th key={h} className="px-4 py-3 text-left text-xs font-bold tracking-widest uppercase" style={{color:'#3D5070',borderBottom:'1px solid rgba(96,165,250,0.07)'}}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {recentOS.length === 0 ? (
                  <tr><td colSpan={6} className="px-4 py-8 text-center text-sm" style={{color:'#3D5070'}}>Nenhuma OS ainda</td></tr>
                ) : recentOS.map(os => {
                  const [bg, color] = statusBadge(os.status)
                  return (
                    <tr key={os.id} className="transition-colors" style={{'--hover-bg':'rgba(96,165,250,0.03)'}}
                      onMouseEnter={e=>e.currentTarget.style.background='rgba(96,165,250,0.03)'}
                      onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                      <td className="px-4 py-3 text-xs font-mono" style={{color:'#3D5070',borderBottom:'1px solid rgba(96,165,250,0.05)'}}># {os.id}</td>
                      <td className="px-4 py-3 text-sm font-bold" style={{color:'#EEF2FF',borderBottom:'1px solid rgba(96,165,250,0.05)'}}>{os.cliente_id}</td>
                      <td className="px-4 py-3 text-sm" style={{color:'#8899BB',borderBottom:'1px solid rgba(96,165,250,0.05)'}}>{os.tecnico_id || '—'}</td>
                      <td className="px-4 py-3 text-sm" style={{color:'#8899BB',borderBottom:'1px solid rgba(96,165,250,0.05)'}}>{os.tipo_servico || '—'}</td>
                      <td className="px-4 py-3" style={{borderBottom:'1px solid rgba(96,165,250,0.05)'}}>
                        <span className="px-2.5 py-1 rounded-full text-xs font-bold" style={{background:bg,color}}>{os.status}</span>
                      </td>
                      <td className="px-4 py-3 text-xs" style={{color:'#3D5070',borderBottom:'1px solid rgba(96,165,250,0.05)'}}>{fmtDate(os.criado_em)}</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
