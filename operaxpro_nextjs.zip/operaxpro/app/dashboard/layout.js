'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase'
import Sidebar from '@/components/layout/Sidebar'

export default function DashboardLayout({ children }) {
  const [user, setUser]     = useState(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    async function checkAuth() {
      const { data: { session } } = await supabase.auth.getSession()
      if (!session) { router.push('/login'); return }
      // Buscar perfil do usuário
      const { data: perfil } = await supabase
        .from('usuarios')
        .select('nome, perfil, empresa_id')
        .eq('auth_id', session.user.id)
        .single()
      setUser({ ...session.user, ...perfil })
      setLoading(false)
    }
    checkAuth()

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (!session) router.push('/login')
    })
    return () => subscription.unsubscribe()
  }, [router])

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center" style={{background:'#0B1120'}}>
      <div className="text-center">
        <div className="w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-4" style={{background:'#1A56DB'}}>
          <svg width="24" height="24" viewBox="0 0 28 28" fill="none">
            <rect x="3" y="3" width="10" height="10" rx="2.5" fill="white"/>
            <rect x="15" y="3" width="10" height="10" rx="2.5" fill="white" opacity="0.5"/>
            <rect x="3" y="15" width="10" height="10" rx="2.5" fill="white" opacity="0.5"/>
            <path d="M15 20.5L18.5 24.5L25 16" stroke="white" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
        <div className="text-sm font-semibold animate-pulse" style={{color:'#3D5070'}}>Carregando OperaxPro...</div>
      </div>
    </div>
  )

  return (
    <div className="flex h-screen overflow-hidden" style={{background:'#0B1120'}}>
      <Sidebar user={user}/>
      <main className="flex-1 overflow-y-auto">
        {children}
      </main>
    </div>
  )
}
