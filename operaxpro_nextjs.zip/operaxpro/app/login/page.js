'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase'

export default function Login() {
  const [email, setEmail]     = useState('')
  const [senha, setSenha]     = useState('')
  const [erro, setErro]       = useState('')
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  async function handleLogin(e) {
    e.preventDefault()
    setLoading(true)
    setErro('')
    const { data, error } = await supabase.auth.signInWithPassword({ email, password: senha })
    if (error) { setErro('E-mail ou senha incorretos.'); setLoading(false); return }
    router.push('/dashboard')
  }

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden" style={{background:'#0B1120'}}>
      {/* Grid */}
      <div className="absolute inset-0" style={{backgroundImage:'linear-gradient(rgba(26,86,219,.05) 1px,transparent 1px),linear-gradient(90deg,rgba(26,86,219,.05) 1px,transparent 1px)',backgroundSize:'48px 48px'}}/>
      {/* Glows */}
      <div className="absolute rounded-full blur-[100px] opacity-20" style={{width:600,height:600,left:-200,top:-200,background:'#1A56DB'}}/>
      <div className="absolute rounded-full blur-[100px] opacity-15" style={{width:400,height:400,right:-100,bottom:-100,background:'#06B6D4'}}/>

      <div className="relative z-10 w-full max-w-md px-4">
        <div className="rounded-2xl p-10 shadow-2xl" style={{background:'#0F1729',border:'1px solid rgba(96,165,250,0.15)'}}>

          {/* Logo */}
          <div className="flex items-center gap-3 mb-1">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0" style={{background:'#1A56DB',boxShadow:'0 0 24px rgba(26,86,219,.5)'}}>
              <svg width="26" height="26" viewBox="0 0 28 28" fill="none">
                <rect x="3" y="3" width="10" height="10" rx="2.5" fill="white"/>
                <rect x="15" y="3" width="10" height="10" rx="2.5" fill="white" opacity="0.5"/>
                <rect x="3" y="15" width="10" height="10" rx="2.5" fill="white" opacity="0.5"/>
                <path d="M15 20.5L18.5 24.5L25 16" stroke="white" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <span className="text-2xl font-black tracking-tight" style={{color:'#EEF2FF'}}>
              Operax<span style={{color:'#67E8F9',fontWeight:400}}>Pro</span>
            </span>
          </div>
          <p className="text-sm mb-8 pl-16" style={{color:'#3D5070'}}>Sua equipe, sob controle.</p>

          {erro && (
            <div className="mb-5 px-4 py-3 rounded-xl text-sm font-semibold" style={{background:'rgba(239,68,68,.1)',border:'1px solid rgba(239,68,68,.25)',color:'#FCA5A5'}}>
              {erro}
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <label className="block text-xs font-bold mb-2 tracking-widest uppercase" style={{color:'#3D5070'}}>E-mail</label>
              <input type="email" required value={email} onChange={e=>setEmail(e.target.value)}
                placeholder="seu@email.com"
                className="w-full rounded-xl px-4 py-3 text-sm outline-none transition-all"
                style={{background:'#162040',border:'1px solid rgba(96,165,250,0.13)',color:'#EEF2FF'}}
                onFocus={e=>{e.target.style.borderColor='#1A56DB'}}
                onBlur={e=>{e.target.style.borderColor='rgba(96,165,250,0.13)'}}
              />
            </div>
            <div>
              <label className="block text-xs font-bold mb-2 tracking-widest uppercase" style={{color:'#3D5070'}}>Senha</label>
              <input type="password" required value={senha} onChange={e=>setSenha(e.target.value)}
                placeholder="••••••••"
                className="w-full rounded-xl px-4 py-3 text-sm outline-none transition-all"
                style={{background:'#162040',border:'1px solid rgba(96,165,250,0.13)',color:'#EEF2FF'}}
                onFocus={e=>{e.target.style.borderColor='#1A56DB'}}
                onBlur={e=>{e.target.style.borderColor='rgba(96,165,250,0.13)'}}
              />
            </div>
            <button type="submit" disabled={loading}
              className="w-full font-bold py-4 rounded-xl transition-all text-white mt-2"
              style={{background:'#1A56DB',boxShadow:'0 4px 20px rgba(26,86,219,.4)',opacity:loading?0.6:1}}>
              {loading ? 'Entrando...' : 'Entrar no OperaxPro'}
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}
