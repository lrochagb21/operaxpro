'use client'
import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import AppLayout from '@/components/layout/AppLayout'

const INPUT = "w-full rounded-xl px-4 py-2.5 text-sm outline-none transition-all"
const IS    = {background:'#162040',border:'1px solid rgba(96,165,250,0.13)',color:'#EEF2FF'}

export default function Tecnicos() {
  const [list, setList]       = useState([])
  const [loading, setLoading] = useState(true)
  const [form, setForm]       = useState({nome:'',telefone:'',email:'',especialidade:'',endereco:'',cidade:'',status:'ativo'})
  const [saving, setSaving]   = useState(false)
  const [msg, setMsg]         = useState('')

  useEffect(() => { loadTecs() }, [])

  async function loadTecs() {
    const { data } = await supabase.from('usuarios').select('*').eq('perfil','tecnico').order('criado_em',{ascending:false})
    setList(data || [])
    setLoading(false)
  }

  async function save(e) {
    e.preventDefault()
    setSaving(true)
    const { data:{ session } } = await supabase.auth.getSession()
    const { data: me } = await supabase.from('usuarios').select('empresa_id').eq('auth_id',session.user.id).single()
    const { error } = await supabase.from('usuarios').insert({...form, perfil:'tecnico', empresa_id: me.empresa_id})
    if (error) { setMsg('Erro: '+error.message) }
    else { setMsg('✅ Técnico cadastrado!'); setForm({nome:'',telefone:'',email:'',especialidade:'',endereco:'',cidade:'',status:'ativo'}); loadTecs() }
    setSaving(false)
    setTimeout(()=>setMsg(''),3000)
  }

  async function del(id) {
    if (!confirm('Remover técnico?')) return
    await supabase.from('usuarios').delete().eq('id',id)
    loadTecs()
  }

  const stColor = s => s==='ativo' ? ['rgba(16,185,129,.15)','#34D399'] : s==='ferias' ? ['rgba(245,158,11,.15)','#FCD34D'] : ['rgba(239,68,68,.15)','#FCA5A5']

  return (
    <AppLayout>
      <div className="p-6">
        <div className="mb-6">
          <h1 className="text-2xl font-black tracking-tight" style={{color:'#EEF2FF'}}>Técnicos</h1>
          <p className="text-sm mt-1" style={{color:'#3D5070'}}>Cadastro e gestão de técnicos de campo</p>
        </div>

        {/* Form */}
        <div className="rounded-2xl p-6 mb-6" style={{background:'#0F1729',border:'1px solid rgba(96,165,250,0.07)'}}>
          <h2 className="font-black mb-5 pb-4 text-sm" style={{color:'#EEF2FF',borderBottom:'1px solid rgba(96,165,250,0.07)'}}>👷 Cadastrar Técnico</h2>
          {msg && <div className="mb-4 px-4 py-2.5 rounded-xl text-sm font-semibold" style={{background:'rgba(16,185,129,.1)',border:'1px solid rgba(16,185,129,.2)',color:'#34D399'}}>{msg}</div>}
          <form onSubmit={save}>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
              {[
                {id:'nome',label:'Nome Completo *',type:'text',ph:'João Silva',req:true},
                {id:'telefone',label:'Telefone *',type:'text',ph:'(11) 99999-9999',req:true},
                {id:'email',label:'E-mail',type:'email',ph:'joao@email.com'},
                {id:'endereco',label:'Endereço',type:'text',ph:'Rua, número - Bairro'},
                {id:'cidade',label:'Cidade / Estado',type:'text',ph:'São Paulo / SP'},
              ].map(f => (
                <div key={f.id}>
                  <label className="block text-xs font-bold mb-1.5 tracking-widest uppercase" style={{color:'#3D5070'}}>{f.label}</label>
                  <input type={f.type} required={f.req} placeholder={f.ph} value={form[f.id]} onChange={e=>setForm({...form,[f.id]:e.target.value})}
                    className={INPUT} style={IS}
                    onFocus={e=>e.target.style.borderColor='#1A56DB'}
                    onBlur={e=>e.target.style.borderColor='rgba(96,165,250,0.13)'}/>
                </div>
              ))}
              <div>
                <label className="block text-xs font-bold mb-1.5 tracking-widest uppercase" style={{color:'#3D5070'}}>Especialidade</label>
                <select value={form.especialidade} onChange={e=>setForm({...form,especialidade:e.target.value})}
                  className={INPUT} style={{...IS,appearance:'none',cursor:'pointer'}}>
                  <option value="">Selecione...</option>
                  {['Elétrica','Hidráulica','Informática / TI','Refrigeração / Ar-condicionado','Instalações','Manutenção Geral'].map(o=><option key={o}>{o}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold mb-1.5 tracking-widest uppercase" style={{color:'#3D5070'}}>Status</label>
                <select value={form.status} onChange={e=>setForm({...form,status:e.target.value})}
                  className={INPUT} style={{...IS,appearance:'none',cursor:'pointer'}}>
                  <option value="ativo">Ativo</option>
                  <option value="inativo">Inativo</option>
                  <option value="ferias">Férias</option>
                </select>
              </div>
            </div>
            <div className="flex justify-end gap-3">
              <button type="button" onClick={()=>setForm({nome:'',telefone:'',email:'',especialidade:'',endereco:'',cidade:'',status:'ativo'})}
                className="px-5 py-2.5 rounded-xl text-sm font-bold transition-all" style={{background:'#162040',color:'#8899BB',border:'1px solid rgba(96,165,250,0.13)'}}>
                Limpar
              </button>
              <button type="submit" disabled={saving}
                className="px-6 py-2.5 rounded-xl text-sm font-bold text-white transition-all" style={{background:'#1A56DB',opacity:saving?0.6:1}}>
                {saving ? 'Salvando...' : '💾 Salvar Técnico'}
              </button>
            </div>
          </form>
        </div>

        {/* Tabela */}
        <div className="rounded-2xl overflow-hidden" style={{background:'#0F1729',border:'1px solid rgba(96,165,250,0.07)'}}>
          <div className="px-5 py-4" style={{borderBottom:'1px solid rgba(96,165,250,0.07)'}}>
            <span className="font-black text-sm" style={{color:'#EEF2FF'}}>Lista de Técnicos ({list.length})</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr style={{background:'rgba(15,23,41,0.6)'}}>
                  {['Nome','Telefone','E-mail','Especialidade','Status',''].map(h=>(
                    <th key={h} className="px-4 py-3 text-left text-xs font-bold tracking-widest uppercase" style={{color:'#3D5070',borderBottom:'1px solid rgba(96,165,250,0.07)'}}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr><td colSpan={6} className="px-4 py-8 text-center text-sm" style={{color:'#3D5070'}}>Carregando...</td></tr>
                ) : list.length === 0 ? (
                  <tr><td colSpan={6} className="px-4 py-8 text-center text-sm" style={{color:'#3D5070'}}>Nenhum técnico cadastrado</td></tr>
                ) : list.map(t => {
                  const [bg,color] = stColor(t.status)
                  return (
                    <tr key={t.id} onMouseEnter={e=>e.currentTarget.style.background='rgba(96,165,250,0.03)'} onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                      <td className="px-4 py-3 text-sm font-bold" style={{color:'#EEF2FF',borderBottom:'1px solid rgba(96,165,250,0.05)'}}>{t.nome}</td>
                      <td className="px-4 py-3 text-sm" style={{color:'#8899BB',borderBottom:'1px solid rgba(96,165,250,0.05)'}}>{t.telefone||'—'}</td>
                      <td className="px-4 py-3 text-sm" style={{color:'#60A5FA',borderBottom:'1px solid rgba(96,165,250,0.05)'}}>{t.email||'—'}</td>
                      <td className="px-4 py-3 text-sm" style={{color:'#8899BB',borderBottom:'1px solid rgba(96,165,250,0.05)'}}>{t.especialidade||'—'}</td>
                      <td className="px-4 py-3" style={{borderBottom:'1px solid rgba(96,165,250,0.05)'}}>
                        <span className="px-2.5 py-1 rounded-full text-xs font-bold" style={{background:bg,color}}>{t.status}</span>
                      </td>
                      <td className="px-4 py-3" style={{borderBottom:'1px solid rgba(96,165,250,0.05)'}}>
                        <button onClick={()=>del(t.id)} className="px-3 py-1 rounded-lg text-xs font-bold transition-all" style={{background:'rgba(239,68,68,.12)',color:'#FCA5A5',border:'1px solid rgba(239,68,68,.25)'}}>🗑</button>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </AppLayout>
  )
}
